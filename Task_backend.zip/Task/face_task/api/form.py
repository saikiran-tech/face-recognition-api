from django import forms
from api.models import Images
class UploadFileForm(forms.ModelForm):
    class Meta:
        model = Images
        fields = '__all__'
