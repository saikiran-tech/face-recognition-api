from django.db import models

# Create your models here.
class Images(models.Model):
    file1 = models.ImageField(upload_to='media/')
    file2 = models.ImageField(upload_to='media/')
