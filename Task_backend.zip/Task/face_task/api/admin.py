from django.contrib import admin
from api.models import Images
# from testapp.models import ImagesRegister your models here.
admin.site.register(Images)
