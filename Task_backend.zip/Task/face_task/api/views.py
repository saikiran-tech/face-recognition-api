from django.shortcuts import render
import face_recognition
from django.http import JsonResponse
from .form import UploadFileForm
# Create your views here.

def upload(request):
    if request.method == "POST":
        form = UploadFileForm(request.POST or None, request.FILES)
        if form.is_valid():
            f1 = request.FILES['file1']
            f2 = request.FILES['file2']
            face1 = face_recognition.load_image_file(f1)
            face2 = face_recognition.load_image_file(f2)
            face1_encode = face_recognition.face_encodings(face1)[0]
            face2_encode = face_recognition.face_encodings(face2)[0]
            results = face_recognition.face_distance([face1_encode], face2_encode)
            data = results.tolist()
            final_data = "Distance of images set-1 is {}".format(data)
            form.save()
            return JsonResponse(final_data, safe=False)

    else:
        form = UploadFileForm()
    return render(request, 'upload.html', {'form': form})
