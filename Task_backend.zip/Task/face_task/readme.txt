#Task for backend developer#
--> Created an api for accepting 2 images using django.
--> Provided required logic for loading the images and calculating the distance of the images using face_recognition library.
--> Connected S3 bucket for saving the images.
--> Saved the output as JSON responses in the s3 bucket.
--> Created a Docker file and docker-compose.yml
 #Required dependencies#
  python==3.7
  django>=2.2
  boto3
  django-storages
  face_recognition 
